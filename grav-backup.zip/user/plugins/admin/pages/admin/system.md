---
title: Configuration
template: config
expires: 0

access:
    admin.configuration.system: true
    admin.super: true
---
