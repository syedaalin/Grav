---
title: Changelog

access:
    admin.plugins: true
    admin.maintenance: true
    admin.themes: true
    admin.super: true
---
