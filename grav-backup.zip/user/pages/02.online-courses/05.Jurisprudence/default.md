<style>
  /* --- 1. THEME VARIABLES --- */
  :root {
    --primary: #0e7490;    /* Deep Teal */
    --primary-dark: #164e63;
    --accent: #d97706;     /* Islamic Gold */
    --accent-glow: #f59e0b;
    --text-main: #1f2937;
    --text-muted: #4b5563;
    --bg-page: #f8fafc;    /* Very light cool gray */
    --bg-card: #ffffff;
    --shadow-soft: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
    --shadow-hover: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
  }

  /* --- 2. GLOBAL TYPOGRAPHY --- */
  body {
    font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
    color: var(--text-main);
    background-color: var(--bg-page);
    line-height: 1.7;
    margin: 0;
  }

  h1, h2, h3 {
    font-family: 'Georgia', 'Times New Roman', serif; /* Scholarly feel */
    color: var(--primary-dark);
    margin-top: 0;
  }

  /* --- 3. HERO SECTION (UPGRADED) --- */
  .hero-section {
    background: radial-gradient(circle at top right, #155e75, #0e7490), 
                url('https://www.transparenttextures.com/patterns/arabesque.png'); /* Pattern overlay */
    color: white;
    text-align: center;
    padding: 80px 20px;
    border-radius: 16px;
    margin-bottom: 50px;
    box-shadow: var(--shadow-hover);
    position: relative;
    overflow: hidden;
  }

  .hero-section::before {
    content: '';
    position: absolute;
    top: 0; left: 0; right: 0; bottom: 0;
    background: linear-gradient(45deg, rgba(255,255,255,0.1) 0%, rgba(0,0,0,0.1) 100%);
    pointer-events: none;
  }

  .hero-title {
    font-size: 3rem;
    margin-bottom: 15px;
    text-shadow: 0 2px 4px rgba(0,0,0,0.3);
  }

  .hero-subtitle {
    font-size: 1.3rem;
    font-weight: 300;
    max-width: 700px;
    margin: 0 auto 30px auto;
    color: #e0f2fe;
  }

  /* --- 4. BUTTONS (GLOWING) --- */
  .btn-primary {
    background: linear-gradient(135deg, var(--accent), #b45309);
    color: white;
    padding: 16px 40px;
    border-radius: 50px;
    text-decoration: none;
    font-weight: bold;
    text-transform: uppercase;
    letter-spacing: 1px;
    display: inline-block;
    transition: all 0.3s ease;
    box-shadow: 0 4px 15px rgba(217, 119, 6, 0.4);
    border: 1px solid rgba(255,255,255,0.2);
  }

  .btn-primary:hover {
    transform: translateY(-3px);
    box-shadow: 0 8px 25px rgba(217, 119, 6, 0.6);
    background: linear-gradient(135deg, #f59e0b, #d97706);
    color: white;
  }

  .btn-whatsapp {
    background: #25D366;
    margin-left: 10px;
    box-shadow: 0 4px 15px rgba(37, 211, 102, 0.4);
  }
  .btn-whatsapp:hover {
    background: #1da851;
    box-shadow: 0 8px 25px rgba(37, 211, 102, 0.6);
  }

  /* --- 5. CARDS (GLASS EFFECT) --- */
  .grid-container {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
    gap: 30px;
    margin: 40px 0;
  }

  .feature-card {
    background: var(--bg-card);
    border-radius: 12px;
    padding: 30px;
    box-shadow: var(--shadow-soft);
    border: 1px solid rgba(0,0,0,0.05);
    transition: all 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    position: relative;
    overflow: hidden;
  }

  .feature-card:hover {
    transform: translateY(-10px);
    box-shadow: var(--shadow-hover);
    border-color: var(--primary);
  }
  
  .feature-card::top {
    content: '';
    position: absolute;
    top: 0; left: 0; width: 100%; height: 4px;
    background: var(--primary);
    transform: scaleX(0);
    transition: transform 0.4s ease;
    transform-origin: left;
  }
  
  .feature-card:hover::top {
    transform: scaleX(1);
  }

  .card-icon {
    font-size: 2rem;
    margin-bottom: 15px;
    display: block;
  }

  /* --- 6. PRICING TABLES (CLEAN) --- */
  .pricing-wrapper {
    overflow-x: auto;
    border-radius: 12px;
    box-shadow: var(--shadow-soft);
    background: white;
  }

  table {
    width: 100%;
    border-collapse: collapse;
    min-width: 600px; /* Forces scroll on small mobile */
  }

  th {
    background-color: var(--primary);
    color: white;
    padding: 18px;
    text-align: left;
    font-weight: 600;
    text-transform: uppercase;
    font-size: 0.85rem;
    letter-spacing: 0.5px;
  }

  td {
    padding: 16px 18px;
    border-bottom: 1px solid #e5e7eb;
    color: var(--text-muted);
  }

  tr:last-child td { border-bottom: none; }
  
  tr:nth-child(even) { background-color: #f8fafc; }
  
  tr:hover td {
    background-color: #f0f9ff;
    color: var(--primary-dark);
  }

  .price-tag {
    font-weight: bold;
    color: var(--primary-dark);
  }

  /* --- 7. FAQ ACCORDION --- */
  details {
    background: white;
    margin-bottom: 15px;
    border-radius: 8px;
    border: 1px solid #e5e7eb;
    overflow: hidden;
    transition: all 0.3s ease;
  }

  details:hover {
    box-shadow: 0 4px 6px rgba(0,0,0,0.05);
    border-color: var(--primary);
  }

  summary {
    padding: 20px;
    cursor: pointer;
    font-weight: 600;
    color: var(--primary-dark);
    list-style: none;
    position: relative;
    background: white;
  }

  summary::-webkit-details-marker { display: none; }

  summary::after {
    content: '+';
    position: absolute;
    right: 20px;
    font-size: 1.5rem;
    line-height: 1;
    color: var(--accent);
    transition: transform 0.3s ease;
  }

  details[open] summary::after {
    transform: rotate(45deg);
  }

  .faq-answer {
    padding: 0 20px 20px 20px;
    color: var(--text-muted);
    border-top: 1px solid #f3f4f6;
    background: #fafafa;
    padding-top: 15px;
  }

  /* --- 8. UTILITIES --- */
  .container { max-width: 1100px; margin: 0 auto; padding: 20px; }
  .text-center { text-align: center; }
  .section-title { font-size: 2.2rem; margin-bottom: 40px; text-align: center; color: var(--primary-dark); position: relative; display: inline-block; }
  .section-title::after {
    content: ''; display: block; width: 60px; height: 3px; 
    background: var(--accent); margin: 10px auto 0; border-radius: 2px;
  }
  
  .promise-box {
    background: #fffbeb; /* light yellow */
    border-left: 5px solid var(--accent);
    padding: 30px;
    border-radius: 0 8px 8px 0;
    margin: 60px 0;
    font-style: italic;
    font-size: 1.1rem;
    color: #92400e;
  }

</style>

<div class="container">

  <div class="hero-section">
    <h1 class="hero-title" style="color: white;">Master Islamic Jurisprudence (Fiqh)</h1>
    <p class="hero-subtitle">Discover Shariah Through the Authentic Teachings of the Ahl al-Bayt (AS)</p>
    <br>
    <a href="#enroll" class="btn-primary">Enroll Now</a>
  </div>

  <div class="text-center" style="max-width: 800px; margin: 0 auto 60px auto;">
    <h2 style="color: var(--primary);">Explore Shariah</h2>
    <p style="font-size: 1.1rem; color: var(--text-muted);">
      Dive into the wisdom of Shariah with our 100% online Fiqh course. Guided by expert scholars, learn from authentic sources like the Qur’an and Hadith. Suitable for all levels, with live sessions in Urdu and English.
    </p>
  </div>

  <div class="text-center"><h2 class="section-title">What You’ll Achieve</h2></div>
  <div class="grid-container">
    <div class="feature-card">
      <span class="card-icon">⚖️</span>
      <h3>Understand Shariah</h3>
      <p>Master rulings on worship, finance, and family life according to your Marja’.</p>
    </div>
    <div class="feature-card">
      <span class="card-icon">✅</span>
      <h3>Clarify Obligations</h3>
      <p>Learn the distinct differences between Wājib, Mustahabb, Harām, Makruh, and Mubah.</p>
    </div>
    <div class="feature-card">
      <span class="card-icon">🌐</span>
      <h3>Apply Fiqh Today</h3>
      <p>Navigate modern challenges confidently, such as banking, IVF, and gender interactions.</p>
    </div>
  </div>

  <div class="text-center"><h2 class="section-title">Why Our Course Excels</h2></div>
  <div class="grid-container">
    <div class="feature-card">
      <h3>Authentic Roots</h3>
      <p style="color: var(--text-muted);">Grounded in Shia tradition with Qur’an and Hadith sources.</p>
    </div>
    <div class="feature-card">
      <h3>Expert Scholars</h3>
      <p style="color: var(--text-muted);">Taught by Hawza-trained instructors with modern insights.</p>
    </div>
    <div class="feature-card">
      <h3>Engaging Format</h3>
      <p style="color: var(--text-muted);">Structured, clear, and interactive for global learners.</p>
    </div>
  </div>

  <div style="background: white; padding: 40px; border-radius: 12px; box-shadow: var(--shadow-soft); margin-bottom: 60px;">
    <h3 class="text-center" style="margin-bottom: 30px;">How It Works</h3>
    <div style="display: flex; flex-wrap: wrap; justify-content: center; gap: 20px; text-align: center;">
      <div style="flex: 1; min-width: 150px;"><strong>1. Enroll</strong><br><span style="font-size: 0.9rem; color:#666;">Sign up online</span></div>
      <div style="flex: 1; min-width: 150px;"><strong>2. Learn</strong><br><span style="font-size: 0.9rem; color:#666;">Live or Recorded</span></div>
      <div style="flex: 1; min-width: 150px;"><strong>3. Engage</strong><br><span style="font-size: 0.9rem; color:#666;">Weekly Q&A</span></div>
      <div style="flex: 1; min-width: 150px;"><strong>4. Certify</strong><br><span style="font-size: 0.9rem; color:#666;">Get Certificate</span></div>
    </div>
  </div>

  <div id="enroll">
    <div class="text-center"><h2 class="section-title">Affordable Plans</h2></div>
    
    <h3 style="color: var(--primary);">🇵🇰 National Students (PKR)</h3>
    <div class="pricing-wrapper">
      <table>
        <thead>
          <tr>
            <th>Study Plan</th>
            <th>Frequency</th>
            <th>Monthly Classes</th>
            <th>Fee/Class</th>
            <th>Monthly Total</th>
          </tr>
        </thead>
        <tbody>
          <tr><td>Basic</td><td>1 Day / Week</td><td>4</td><td>500</td><td class="price-tag">PKR 2,000</td></tr>
          <tr><td>Standard</td><td>2 Days / Week</td><td>8</td><td>500</td><td class="price-tag">PKR 4,000</td></tr>
          <tr><td>Intensive</td><td>3 Days / Week</td><td>12</td><td>500</td><td class="price-tag">PKR 6,000</td></tr>
          <tr><td>Advanced</td><td>4 Days / Week</td><td>16</td><td>500</td><td class="price-tag">PKR 8,000</td></tr>
          <tr><td>Pro</td><td>5 Days / Week</td><td>20</td><td>500</td><td class="price-tag">PKR 10,000</td></tr>
          <tr><td>Immersion</td><td>6 Days / Week</td><td>24</td><td>500</td><td class="price-tag">PKR 12,000</td></tr>
        </tbody>
      </table>
    </div>

    <br><br>

    <h3 style="color: var(--primary);">🌍 International Students (USD)</h3>
    <div class="pricing-wrapper">
      <table>
        <thead>
          <tr>
            <th>Study Plan</th>
            <th>Frequency</th>
            <th>Monthly Classes</th>
            <th>Fee/Class</th>
            <th>Monthly Total</th>
          </tr>
        </thead>
        <tbody>
          <tr><td>Basic</td><td>1 Day / Week</td><td>4</td><td>$1,000</td><td class="price-tag">USD 4,000</td></tr>
          <tr><td>Standard</td><td>2 Days / Week</td><td>8</td><td>$1,000</td><td class="price-tag">USD 8,000</td></tr>
          <tr><td>Intensive</td><td>3 Days / Week</td><td>12</td><td>$1,000</td><td class="price-tag">USD 12,000</td></tr>
        </tbody>
      </table>
    </div>
  </div>

  <div class="promise-box">
    <strong>Our Promise:</strong>
    <br>
    We are dedicated to empowering you with authentic Shia Fiqh knowledge, ensuring clarity, accessibility, and spiritual growth through a trusted, community-endorsed platform.
  </div>

  <div class="text-center"><h2 class="section-title">Frequently Asked Questions</h2></div>
  
  <details>
    <summary>Who can enroll?</summary>
    <div class="faq-answer">Youth, professionals, families, and converts seeking Fiqh knowledge.</div>
  </details>

  <details>
    <summary>How long is the course?</summary>
    <div class="faq-answer">12 weeks with lifetime material access.</div>
  </details>

  <details>
    <summary>Are recordings available?</summary>
    <div class="faq-answer">Yes, included in Standard and Premium plans.</div>
  </details>
  
  <details>
    <summary>Is financial aid offered?</summary>
    <div class="faq-answer">Scholarships available for deserving students.</div>
  </details>

  <div class="text-center" style="margin-top: 80px; padding-bottom: 40px;">
    <h2 style="color: var(--primary-dark);">Start Your Fiqh Journey Today</h2>
    <p>Purify your actions and follow Imam Ja’far al-Sadiq (AS).</p>
    <br>
    <a href="#join" class="btn-primary">Join Now</a>
    <a href="https://wa.me/923022452000" class="btn-primary btn-whatsapp">WhatsApp Us</a>
    
    <p style="margin-top: 30px; font-size: 0.9rem; color: #888;">
      📧 info@aabtaab.com | 📱 +92 302 2452000
    </p>
  </div>

</div>