<div align="center">


<img src="https://placehold.co/800x300?text=Akhlaq+Course+Banner" alt="Islamic Ethics Banner" width="100%">

</div>

---

##  Discover Islamic Ethics
Join our **100% online Akhlaq course** rooted in Shia Islam. Learn from authentic sources like *Nahjul Balagha* and *Sahifa Sajjadiya*, guided by expert scholars.

> **"Perfect for all ages, with live classes and reflections in Urdu and English."**

---

##  What You’ll Achieve

| **Purify Your Soul** 🤍 | **Embody Virtues** 🌿 | **Navigate Challenges** 🧭 |
| :--- | :--- | :--- |
| Overcome pride, jealousy, and greed using *Tawbah* and self-monitoring. | Cultivate sincerity, humility, and compassion inspired by **Imam Ali (AS)**. | Apply ethics to modern issues like social media and honesty in business. |

---

##  Why Our Course Stands Out

* ✅ **Authentic Shia Roots**
    *Based on Qur’an, Hadith, and teachings of the Ahl al-Bayt (AS).*
* 📈 **Transformative Growth**
    *Daily Akhlaq goals for real-life spiritual improvement.*
* 🎓 **Expert Scholars**
    *Guided by Hawza-trained mentors with practical insights.*

---

## ️ How It Works

1.  📝 **Sign Up:** Choose a plan and enroll online.
2.  💻 **Learn:** Join live classes or watch recordings.
3.  🤔 **Reflect:** Complete weekly self-reflection tasks.
4.  💬 **Engage:** Ask questions in live Q&A sessions.
5.  📜 **Succeed:** Earn a Certificate of Completion.

---


### 🇵🇰 National Students (PKR)

| Plan | Frequency | Monthly Classes | Fee/Class | **Monthly Total** |
| :--- | :--- | :---: | :---: | :---: |
| **Basic** | 1 Day/Week | 4 | 500 | **PKR 2,000** |
| **Standard** | 2 Days/Week | 8 | 500 | **PKR 4,000** |
| **Intensive** | 3 Days/Week | 12 | 500 | **PKR 6,000** |
| **Advanced** | 4 Days/Week | 16 | 500 | **PKR 8,000** |
| **Pro** | 5 Days/Week | 20 | 500 | **PKR 10,000** |
| **Immersion**| 6 Days/Week | 24 | 500 | **PKR 12,000** |

<br>

### 🌍 International Students (USD)

| Plan | Frequency | Monthly Classes | Fee/Class | **Monthly Total** |
| :--- | :--- | :---: | :---: | :---: |
| **Basic** | 1 Day/Week | 4 | $1,000 | **$4,000** |
| **Standard** | 2 Days/Week | 8 | $1,000 | **$8,000** |
| **Intensive** | 3 Days/Week | 12 | $1,000 | **$12,000** |
| **Advanced** | 4 Days/Week | 16 | $1,000 | **$16,000** |
| **Pro** | 5 Days/Week | 20 | $1,000 | **$20,000** |
| **Immersion**| 6 Days/Week | 24 | $1,000 | **$24,000** |

> *⚠️ Note: Please verify International pricing values ($1,000/class seems high compared to PKR rates).*

---

## Begin Your Spiritual Journey

**Live the Akhlaq of the Ahl al-Bayt (AS). Enroll today!**

[ **JOIN NOW** ](#join) | [ **WHATSAPP US** ](#whatsapp)

**Email:** info@aabtaab.com
**Phone:** +92 302 2452000

---

### Our Promise
> "We are committed to guiding you toward spiritual excellence through authentic Shia teachings, fostering character growth, and building a supportive community."

### FAQs

<details>
<summary><strong>Who can enroll?</strong></summary>
Anyone seeking spiritual growth, from teens to educators.
</details>

<details>
<summary><strong>How long is the course?</strong></summary>
8-12 weeks with flexible live and recorded classes.
</details>

<details>
<summary><strong>Are recordings included?</strong></summary>
Yes, in Standard and Premium plans.
</details>

<details>
<summary><strong>Is financial aid available?</strong></summary>
Free/subsidized access for eligible students.
</details>