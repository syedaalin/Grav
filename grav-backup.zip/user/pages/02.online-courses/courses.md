---
title: Online Courses
---

# Our Online Courses

Discover our carefully curated online courses in Islamic sciences, delivered by qualified scholars with years of experience.

<div class="courses-intro">
    <p>Each course is 100% online, self-paced, and includes video lessons, readings, quizzes, and community support. Enroll today and deepen your knowledge from the comfort of your home.</p>
</div>

<div class="course-grid">

{% set courses = page.children %}

{% for course in courses %}
    <div class="course-card">
        {% if course.media.images|first %}
            {% set image = course.media.images|first %}
            {{ image.cropZoom(800,500).html('', course.title, 'course-thumbnail')|raw }}
        {% endif %}

        <div class="course-content">
            <h2>{{ course.title }}</h2>

            {% if course.header.instructor or course.header.duration or course.header.level %}
            <div class="course-meta">
                {% if course.header.instructor %}
                <span><i class="fas fa-chalkboard-teacher"></i> {{ course.header.instructor }}</span>
                {% endif %}
                {% if course.header.duration %}
                <span><i class="fas fa-clock"></i> {{ course.header.duration }}</span>
                {% endif %}
                {% if course.header.level %}
                <span><i class="fas fa-signal"></i> {{ course.header.level }}</span>
                {% endif %}
            </div>
            {% endif %}

            <p class="course-description">
                {{ course.header.short_description|default(course.summary|striptags|slice(0, 180) ~ '...') }}
            </p>

            <div class="course-actions">
                <a href="{{ course.url }}" class="btn-primary">View Details</a>
                <a href="{{ course.url ~ '#enroll' }}" class="btn-secondary">Enroll Now</a>
            </div>
        </div>
    </div>
{% endfor %}

{% if courses|length == 0 %}
    <p class="no-courses">No courses available at the moment. Please check back soon!</p>
{% endif %}

</div>

<style>
.courses-intro {
    text-align: center;
    max-width: 800px;
    margin: 2rem auto 4rem;
    font-size: 1.1rem;
    line-height: 1.7;
    color: #555;
}

.course-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(360px, 1fr));
    gap: 2.5rem;
    margin-top: 2rem;
    padding: 1rem;
}

.course-card {
    background: white;
    border-radius: 16px;
    overflow: hidden;
    box-shadow: 0 8px 25px rgba(0,0,0,0.12);
    transition: all 0.4s ease;
    display: flex;
    flex-direction: column;
}

.course-card:hover {
    transform: translateY(-12px);
    box-shadow: 0 20px 40px rgba(0,0,0,0.18);
}

.course-thumbnail {
    width: 100%;
    height: 220px;
    object-fit: cover;
}

.course-content {
    padding: 1.8rem;
    flex-grow: 1;
    display: flex;
    flex-direction: column;
}

.course-content h2 {
    margin: 0 0 1rem 0;
    font-size: 1.8rem;
    color: #333;
}

.course-meta {
    display: flex;
    flex-wrap: wrap;
    gap: 1.2rem;
    margin-bottom: 1rem;
    font-size: 0.95rem;
    color: #666;
}

.course-meta span {
    display: flex;
    align-items: center;
    gap: 0.5rem;
}

.course-description {
    flex-grow: 1;
    color: #555;
    line-height: 1.6;
    margin-bottom: 1.5rem;
}

.course-actions {
    display: flex;
    gap: 1rem;
    margin-top: