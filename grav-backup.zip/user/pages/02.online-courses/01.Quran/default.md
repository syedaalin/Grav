---
title: Quran
header:
    short_description: Enroll now in our online course to get the best teachings
---

### Course Overview
Full detailed description of the Quran course goes here...

### What You'll Learn
- Tajweed rules
- Tafsir basics
- Memorization techniques
 etc.